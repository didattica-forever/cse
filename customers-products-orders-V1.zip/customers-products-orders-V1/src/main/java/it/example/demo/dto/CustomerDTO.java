package it.example.demo.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class CustomerDTO {
    private Integer id;
    private String firstName;
    private String lastName;
    private String email;
    private String phone;
    private String address;
    private String city;
    private boolean active;
    private LocalDateTime creationDate;
    private LocalDateTime updateDate;
}

// File: src/main/java/it/example/demo/dto/CustomerCreateRequest.java
