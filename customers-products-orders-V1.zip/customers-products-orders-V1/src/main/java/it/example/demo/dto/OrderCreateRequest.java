package it.example.demo.dto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.List;

@Data
public class OrderCreateRequest {

    @NotNull
    private Integer customerId;

    @NotEmpty
    private List<OrderItemRequest> items;
}

// File: src/main/java/it/example/demo/dto/OrderStatusUpdateRequest.java
