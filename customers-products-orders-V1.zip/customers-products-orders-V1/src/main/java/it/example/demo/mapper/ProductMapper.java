package it.example.demo.mapper;

import it.example.demo.dto.ProductCreateRequest;
import it.example.demo.dto.ProductDTO;
import it.example.demo.dto.ProductUpdateRequest;
import it.example.demo.entity.Product;

import java.time.LocalDateTime;

public final class ProductMapper {

    private ProductMapper() {
    }

    public static ProductDTO toDto(Product entity) {
        ProductDTO dto = new ProductDTO();
        dto.setId(entity.getId());
        dto.setProductName(entity.getProductName());
        dto.setPrice(entity.getPrice());
        dto.setStock(entity.getStock());
        dto.setCreatedAt(entity.getCreatedAt());
        dto.setUpdatedAt(entity.getUpdatedAt());
        return dto;
    }

    public static Product fromCreateRequest(ProductCreateRequest req) {
        Product p = new Product();
        p.setProductName(req.getProductName());
        p.setPrice(req.getPrice());
        p.setStock(req.getStock());
        LocalDateTime now = LocalDateTime.now();
        p.setCreatedAt(now);
        p.setUpdatedAt(now);
        return p;
    }

    public static void updateEntityFromRequest(ProductUpdateRequest req, Product entity) {
        entity.setProductName(req.getProductName());
        entity.setPrice(req.getPrice());
        entity.setStock(req.getStock());
        entity.setUpdatedAt(LocalDateTime.now());
    }
}

// File: src/main/java/it/example/demo/mapper/OrderMapper.java
