package it.example.demo.service;

import it.example.demo.dto.*;
import it.example.demo.entity.Customer;
import it.example.demo.entity.Order;
import it.example.demo.entity.OrderItem;
import it.example.demo.entity.Product;
import it.example.demo.exception.ResourceNotFoundException;
import it.example.demo.mapper.OrderMapper;
import it.example.demo.repository.CustomerRepository;
import it.example.demo.repository.OrderRepository;
import it.example.demo.repository.ProductRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class OrderService {

    private final OrderRepository orderRepository;
    private final CustomerRepository customerRepository;
    private final ProductRepository productRepository;

    public OrderService(OrderRepository orderRepository,
                        CustomerRepository customerRepository,
                        ProductRepository productRepository) {
        this.orderRepository = orderRepository;
        this.customerRepository = customerRepository;
        this.productRepository = productRepository;
    }

    public List<OrderSummaryDTO> getAllOrders() {
        return orderRepository.findAll().stream()
                .map(OrderMapper::toSummaryDto)
                .toList();
    }

    public OrderDetailDTO getOrderById(Integer id) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order with id " + id + " not found"));
        return OrderMapper.toDetailDto(order);
    }

    @Transactional
    public OrderDetailDTO createOrder(OrderCreateRequest request) {
        Customer customer = customerRepository.findById(request.getCustomerId())
                .orElseThrow(() -> new ResourceNotFoundException("Customer with id " + request.getCustomerId() + " not found"));

        Order order = new Order();
        order.setCustomer(customer);
        order.setOrderDate(LocalDateTime.now());
        order.setStatus("NEW");

        List<OrderItem> items = new ArrayList<>();
        BigDecimal total = BigDecimal.ZERO;

        for (OrderItemRequest itemReq : request.getItems()) {
            Product product = productRepository.findById(itemReq.getProductId())
                    .orElseThrow(() -> new ResourceNotFoundException("Product with id " + itemReq.getProductId() + " not found"));

            OrderItem item = new OrderItem();
            item.setOrder(order);
            item.setProduct(product);
            item.setQuantity(itemReq.getQuantity());
            item.setUnitPrice(product.getPrice());

            BigDecimal lineTotal = product.getPrice().multiply(BigDecimal.valueOf(itemReq.getQuantity()));
            total = total.add(lineTotal);

            items.add(item);
        }

        order.setTotalAmount(total);
        order.setItems(items);

        Order saved = orderRepository.save(order);
        return OrderMapper.toDetailDto(saved);
    }

    @Transactional
    public OrderDetailDTO updateOrderStatus(Integer id, OrderStatusUpdateRequest request) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order with id " + id + " not found"));
        order.setStatus(request.getStatus());
        Order saved = orderRepository.save(order);
        return OrderMapper.toDetailDto(saved);
    }

    @Transactional
    public void deleteOrder(Integer id) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order with id " + id + " not found"));
        orderRepository.delete(order);
    }
}

// ============================================================================
// CONTROLLERS
// ============================================================================

// File: src/main/java/it/example/demo/controller/CustomerController.java
