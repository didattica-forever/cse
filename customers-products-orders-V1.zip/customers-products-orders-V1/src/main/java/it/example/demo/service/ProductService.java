package it.example.demo.service;

import it.example.demo.dto.ProductCreateRequest;
import it.example.demo.dto.ProductDTO;
import it.example.demo.dto.ProductUpdateRequest;
import it.example.demo.entity.Product;
import it.example.demo.exception.ResourceNotFoundException;
import it.example.demo.mapper.ProductMapper;
import it.example.demo.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {

    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public List<ProductDTO> getAllProducts() {
        return productRepository.findAll().stream()
                .map(ProductMapper::toDto)
                .toList();
    }

    public ProductDTO getProductById(Integer id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product with id " + id + " not found"));
        return ProductMapper.toDto(product);
    }

    public ProductDTO createProduct(ProductCreateRequest request) {
        Product entity = ProductMapper.fromCreateRequest(request);
        Product saved = productRepository.save(entity);
        return ProductMapper.toDto(saved);
    }

    public ProductDTO updateProduct(Integer id, ProductUpdateRequest request) {
        Product existing = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product with id " + id + " not found"));
        ProductMapper.updateEntityFromRequest(request, existing);
        Product saved = productRepository.save(existing);
        return ProductMapper.toDto(saved);
    }

    public void deleteProduct(Integer id) {
        Product existing = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product with id " + id + " not found"));
        productRepository.delete(existing);
    }
}

// File: src/main/java/it/example/demo/service/OrderService.java
