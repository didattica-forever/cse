package it.example.demo.struttura_standard_progetto_spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StrutturaStandardProgettoSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(StrutturaStandardProgettoSpringApplication.class, args);
	}

}
