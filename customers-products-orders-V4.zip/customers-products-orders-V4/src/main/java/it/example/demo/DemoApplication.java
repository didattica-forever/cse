// ============================================================================
// File: src/main/java/it/example/demo/DemoApplication.java
// ============================================================================
package it.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }
}

// ============================================================================
// ENTITIES
// ============================================================================

// File: src/main/java/it/example/demo/entity/Customer.java
