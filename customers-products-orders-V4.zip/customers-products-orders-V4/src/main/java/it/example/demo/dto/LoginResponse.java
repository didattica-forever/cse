package it.example.demo.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class LoginResponse {

    private String token;
    private long expiresIn;
}

// ============================================================================
// MAPPERS
// ============================================================================

// File: src/main/java/it/example/demo/mapper/CustomerMapper.java
