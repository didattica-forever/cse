package it.example.demo.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class OrderDetailDTO {
    private Integer id;
    private Integer customerId;
    private String customerName;
    private LocalDateTime orderDate;
    private String status;
    private BigDecimal totalAmount;
    private List<OrderItemDTO> items;
}

// ============================================================================
// DTOs - ERROR MODEL
// ============================================================================

// File: src/main/java/it/example/demo/dto/ApiError.java
