package it.example.demo.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class OrderStatusUpdateRequest {

    @NotBlank
    private String status;
}

// File: src/main/java/it/example/demo/dto/OrderItemDTO.java
