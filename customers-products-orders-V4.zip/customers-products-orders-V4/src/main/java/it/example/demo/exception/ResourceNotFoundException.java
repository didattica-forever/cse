package it.example.demo.exception;

public class ResourceNotFoundException extends RuntimeException {

    public ResourceNotFoundException(String message) {
        super(message);
    }
}

// File: src/main/java/it/example/demo/controller/GlobalExceptionHandler.java
