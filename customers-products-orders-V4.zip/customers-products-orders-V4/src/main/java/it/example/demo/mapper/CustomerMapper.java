package it.example.demo.mapper;

import it.example.demo.dto.CustomerCreateRequest;
import it.example.demo.dto.CustomerDTO;
import it.example.demo.dto.CustomerUpdateRequest;
import it.example.demo.entity.Customer;

import java.time.LocalDateTime;

public final class CustomerMapper {

    private CustomerMapper() {
    }

    public static CustomerDTO toDto(Customer entity) {
        CustomerDTO dto = new CustomerDTO();
        dto.setId(entity.getId());
        dto.setFirstName(entity.getFirstName());
        dto.setLastName(entity.getLastName());
        dto.setEmail(entity.getEmail());
        dto.setPhone(entity.getPhone());
        dto.setAddress(entity.getAddress());
        dto.setCity(entity.getCity());
        dto.setActive(entity.isActive());
        dto.setCreationDate(entity.getCreationDate());
        dto.setUpdateDate(entity.getUpdateDate());
        return dto;
    }

    public static Customer fromCreateRequest(CustomerCreateRequest req) {
        Customer c = new Customer();
        c.setFirstName(req.getFirstName());
        c.setLastName(req.getLastName());
        c.setEmail(req.getEmail());
        c.setPhone(req.getPhone());
        c.setAddress(req.getAddress());
        c.setCity(req.getCity());
        c.setActive(true);
        LocalDateTime now = LocalDateTime.now();
        c.setCreationDate(now);
        c.setUpdateDate(now);
        return c;
    }

    public static void updateEntityFromRequest(CustomerUpdateRequest req, Customer entity) {
        entity.setFirstName(req.getFirstName());
        entity.setLastName(req.getLastName());
        entity.setEmail(req.getEmail());
        entity.setPhone(req.getPhone());
        entity.setAddress(req.getAddress());
        entity.setCity(req.getCity());
        entity.setActive(req.isActive());
        entity.setUpdateDate(LocalDateTime.now());
    }
}

// File: src/main/java/it/example/demo/mapper/ProductMapper.java
