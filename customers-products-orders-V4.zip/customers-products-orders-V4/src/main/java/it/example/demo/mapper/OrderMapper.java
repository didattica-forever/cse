package it.example.demo.mapper;

import it.example.demo.dto.OrderDetailDTO;
import it.example.demo.dto.OrderItemDTO;
import it.example.demo.dto.OrderSummaryDTO;
import it.example.demo.entity.Order;
import it.example.demo.entity.OrderItem;

import java.util.List;
import java.util.stream.Collectors;

public final class OrderMapper {

    private OrderMapper() {
    }

    public static OrderSummaryDTO toSummaryDto(Order entity) {
        OrderSummaryDTO dto = new OrderSummaryDTO();
        dto.setId(entity.getId());
        dto.setCustomerId(entity.getCustomer().getId());
        dto.setCustomerName(entity.getCustomer().getFirstName() + " " + entity.getCustomer().getLastName());
        dto.setOrderDate(entity.getOrderDate());
        dto.setStatus(entity.getStatus());
        dto.setTotalAmount(entity.getTotalAmount());
        return dto;
    }

    public static OrderDetailDTO toDetailDto(Order entity) {
        OrderDetailDTO dto = new OrderDetailDTO();
        dto.setId(entity.getId());
        dto.setCustomerId(entity.getCustomer().getId());
        dto.setCustomerName(entity.getCustomer().getFirstName() + " " + entity.getCustomer().getLastName());
        dto.setOrderDate(entity.getOrderDate());
        dto.setStatus(entity.getStatus());
        dto.setTotalAmount(entity.getTotalAmount());

        List<OrderItemDTO> itemDtos = entity.getItems().stream()
                .map(OrderMapper::toItemDto)
                .collect(Collectors.toList());

        dto.setItems(itemDtos);
        return dto;
    }

    public static OrderItemDTO toItemDto(OrderItem item) {
        OrderItemDTO dto = new OrderItemDTO();
        dto.setId(item.getId());
        dto.setProductId(item.getProduct().getId());
        dto.setProductName(item.getProduct().getProductName());
        dto.setQuantity(item.getQuantity());
        dto.setUnitPrice(item.getUnitPrice());
        return dto;
    }
}

// ============================================================================
// EXCEPTIONS & ERROR HANDLING
// ============================================================================

// File: src/main/java/it/example/demo/exception/ResourceNotFoundException.java
