package it.example.demo.repository;

import it.example.demo.entity.OrderItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderItemRepository extends JpaRepository<OrderItem, Integer> {
}

// ============================================================================
// DTOs - CUSTOMERS
// ============================================================================

// File: src/main/java/it/example/demo/dto/CustomerDTO.java
