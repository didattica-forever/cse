package it.example.demo.repository;

import it.example.demo.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Integer> {
}

// File: src/main/java/it/example/demo/repository/OrderRepository.java
