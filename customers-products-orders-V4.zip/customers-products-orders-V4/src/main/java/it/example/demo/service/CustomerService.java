package it.example.demo.service;

import it.example.demo.dto.CustomerCreateRequest;
import it.example.demo.dto.CustomerDTO;
import it.example.demo.dto.CustomerUpdateRequest;
import it.example.demo.entity.Customer;
import it.example.demo.exception.ResourceNotFoundException;
import it.example.demo.mapper.CustomerMapper;
import it.example.demo.repository.CustomerRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerService {

    private final CustomerRepository customerRepository;

    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public List<CustomerDTO> getAllCustomers() {
        return customerRepository.findAll().stream()
                .map(CustomerMapper::toDto)
                .toList();
    }

    public CustomerDTO getCustomerById(Integer id) {
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Customer with id " + id + " not found"));
        return CustomerMapper.toDto(customer);
    }

    public CustomerDTO createCustomer(CustomerCreateRequest request) {
        Customer entity = CustomerMapper.fromCreateRequest(request);
        Customer saved = customerRepository.save(entity);
        return CustomerMapper.toDto(saved);
    }

    public CustomerDTO updateCustomer(Integer id, CustomerUpdateRequest request) {
        Customer existing = customerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Customer with id " + id + " not found"));
        CustomerMapper.updateEntityFromRequest(request, existing);
        Customer saved = customerRepository.save(existing);
        return CustomerMapper.toDto(saved);
    }

    public void deleteCustomer(Integer id) {
        Customer existing = customerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Customer with id " + id + " not found"));
        customerRepository.delete(existing);
    }
}

// File: src/main/java/it/example/demo/service/ProductService.java
