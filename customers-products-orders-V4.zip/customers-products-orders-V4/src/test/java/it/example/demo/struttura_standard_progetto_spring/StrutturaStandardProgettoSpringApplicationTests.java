package it.example.demo.struttura_standard_progetto_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StrutturaStandardProgettoSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
