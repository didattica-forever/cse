package it.example.demo.controller;

import it.example.demo.dto.RegionDTO;
import it.example.demo.service.RegionService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/regions")
public class RegionController {

	private @Autowired RegionService regionService = null;

	/* /regions */
	@GetMapping
	public List<RegionDTO> getAllRegions() {
		return regionService.getAllRegions();
	}

	/* /regions/{id} */
	@GetMapping("/{id}")
	public RegionDTO getRegionById(@PathVariable Integer id) {
		return regionService.getRegionById(id);
	}

}
