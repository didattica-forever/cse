package it.example.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "province")
public class Province {

    @Id
    @Column(name = "id")
    private Integer id;

    @Column(name = "id_regione", nullable = false)
    private Integer idRegione;

    @Column(name = "codice_citta_metropolitana") // visione lato rdbms
    private String codiceCittaMetropolitana; // visione lato programma

    @Column(name = "nome", nullable = false)
    private String nome;

    @Column(name = "sigla_automobilistica")
    private String siglaAutomobilistica;

    @Column(name = "latitudine")
    private Double latitudine;

    @Column(name = "longitudine")
    private Double longitudine;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getIdRegione() {
		return idRegione;
	}

	public void setIdRegione(Integer idRegione) {
		this.idRegione = idRegione;
	}

	public String getCodiceCittaMetropolitana() {
		return codiceCittaMetropolitana;
	}

	public void setCodiceCittaMetropolitana(String codiceCittaMetropolitana) {
		this.codiceCittaMetropolitana = codiceCittaMetropolitana;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getSiglaAutomobilistica() {
		return siglaAutomobilistica;
	}

	public void setSiglaAutomobilistica(String siglaAutomobilistica) {
		this.siglaAutomobilistica = siglaAutomobilistica;
	}

	public Double getLatitudine() {
		return latitudine;
	}

	public void setLatitudine(Double latitudine) {
		this.latitudine = latitudine;
	}

	public Double getLongitudine() {
		return longitudine;
	}

	public void setLongitudine(Double longitudine) {
		this.longitudine = longitudine;
	}


}
