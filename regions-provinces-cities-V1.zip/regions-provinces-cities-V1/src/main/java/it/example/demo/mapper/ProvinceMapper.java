package it.example.demo.mapper;

import it.example.demo.dto.ProvinceDTO;
import it.example.demo.entity.Province;

public final class ProvinceMapper {

    private ProvinceMapper() {
    }

    public static ProvinceDTO toDto(Province entity) {
        if (entity == null) {
            return null;
        }
        return new ProvinceDTO(
                entity.getId(),
                entity.getNome(),
                entity.getIdRegione(),
                entity.getSiglaAutomobilistica(),
                entity.getCodiceCittaMetropolitana(),
                entity.getLatitudine(),
                entity.getLongitudine()
        );
    }
}
