package it.example.demo.mapper;

import it.example.demo.dto.RegionDTO;
import it.example.demo.entity.Region;

public final class RegionMapper {

    private RegionMapper() {
    }

    public static RegionDTO toDto(Region entity) {
        if (entity == null) {
            return null;
        }
        return new RegionDTO(
                entity.getId(),
                entity.getNome(),
                entity.getUrl()
//                ,
//                entity.getLatitudine(),
//                entity.getLongitudine()
        );
    }
}
