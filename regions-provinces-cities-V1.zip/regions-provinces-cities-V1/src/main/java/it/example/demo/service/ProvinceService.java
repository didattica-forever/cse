package it.example.demo.service;

import it.example.demo.dto.ProvinceDTO;
import it.example.demo.entity.Province;
import it.example.demo.mapper.ProvinceMapper;
import it.example.demo.repository.ProvinceRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class ProvinceService {

    private final ProvinceRepository provinceRepository;

    public ProvinceService(ProvinceRepository provinceRepository) {
        this.provinceRepository = provinceRepository;
    }

    public List<ProvinceDTO> getAllProvinces() {
        return provinceRepository.findAll()
                .stream()
                .map(ProvinceMapper::toDto)
                .toList();
    }

    public ProvinceDTO getProvinceById(Integer id) {
        Province province = provinceRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        return ProvinceMapper.toDto(province);
    }
}
