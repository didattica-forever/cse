package it.example.demo.service;

import it.example.demo.dto.RegionDTO;
import it.example.demo.entity.Region;
import it.example.demo.mapper.RegionMapper;
import it.example.demo.repository.RegionRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class RegionService {

    private final @Autowired RegionRepository regionRepository = null;


//    private RegionRepository regionRepository = null;

//    public RegionService(RegionRepository regionRepository) {
//        this.regionRepository = regionRepository;
//    }

//    public void setRegionRepository(RegionRepository regionRepository) {
//		this.regionRepository = regionRepository;
//	}


	public List<RegionDTO> getAllRegions() {
        return regionRepository.findAll()
                .stream()
                .map(RegionMapper::toDto)
                .toList();
    }

    public RegionDTO getRegionById(Integer id) {
        Region region = regionRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        return RegionMapper.toDto(region);
    }
}
