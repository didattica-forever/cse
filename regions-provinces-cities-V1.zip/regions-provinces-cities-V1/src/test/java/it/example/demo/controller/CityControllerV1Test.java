package it.example.demo.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import it.example.demo.dto.CityDTO;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class CityControllerV1Test {

    private static final Logger logger = LoggerFactory.getLogger(CityControllerV1Test.class);

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void shouldReturnAllCities() throws Exception {
        MvcResult result = mockMvc.perform(get("/cities")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String json = result.getResponse().getContentAsString();

        List<CityDTO> cities = objectMapper.readValue(json, new TypeReference<List<CityDTO>>() {});

        assertEquals(7999, cities.size(), "La lista dei comuni deve contenere 7999 elementi");

        logger.info("GET /cities -> total: {}", cities.size());
        if (!cities.isEmpty()) {
            CityDTO first = cities.get(0);
            logger.info("Primo elemento: id={}, name={}, regionId={}, provinceId={}",
                    first.getId(), first.getName(), first.getRegionId(), first.getProvinceId());
        }
    }

    @Test
    void shouldReturnCityById() throws Exception {
        MvcResult result = mockMvc.perform(get("/cities/{id}", 10001)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String json = result.getResponse().getContentAsString();
        CityDTO city = objectMapper.readValue(json, CityDTO.class);

        assertThat(city).isNotNull();
        assertThat(city.getId()).isEqualTo(10001);

        logger.info("GET /cities/10001 -> id={}, name={}, regionId={}, provinceId={}",
                city.getId(), city.getName(), city.getRegionId(), city.getProvinceId());
    }

    @Test
    void shouldReturn404ForUnknownCity() throws Exception {
        MvcResult result = mockMvc.perform(get("/cities/{id}", 999999)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andReturn();

        String body = result.getResponse().getContentAsString();
        logger.info("GET /cities/999999 -> 404 body: {}", body);
    }
}
