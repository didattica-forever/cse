package it.example.demo.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import it.example.demo.dto.ProvinceDTO;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class ProvinceControllerV1Test {

    private static final Logger logger = LoggerFactory.getLogger(ProvinceControllerV1Test.class);

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void shouldReturnAllProvinces() throws Exception {
        MvcResult result = mockMvc.perform(get("/provinces")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String json = result.getResponse().getContentAsString();

        List<ProvinceDTO> provinces = objectMapper.readValue(json, new TypeReference<List<ProvinceDTO>>() {});

        assertEquals(110, provinces.size(), "La lista delle province deve contenere 110 elementi");

        logger.info("GET /provinces -> total: {}", provinces.size());
        if (!provinces.isEmpty()) {
            ProvinceDTO first = provinces.get(0);
            logger.info("Primo elemento: id={}, name={}, regionId={}", first.getId(), first.getName(), first.getRegionId());
        }
    }

    @Test
    void shouldReturnProvinceById() throws Exception {
        MvcResult result = mockMvc.perform(get("/provinces/{id}", 101)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String json = result.getResponse().getContentAsString();
        ProvinceDTO province = objectMapper.readValue(json, ProvinceDTO.class);

        assertThat(province).isNotNull();
        assertThat(province.getId()).isEqualTo(101);

        logger.info("GET /provinces/101 -> id={}, name={}, regionId={}",
                province.getId(), province.getName(), province.getRegionId());
    }

    @Test
    void shouldReturn404ForUnknownProvince() throws Exception {
        MvcResult result = mockMvc.perform(get("/provinces/{id}", 9999)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andReturn();

        String body = result.getResponse().getContentAsString();
        logger.info("GET /provinces/9999 -> 404 body: {}", body);
    }
}

// ============================================================================
// File: src/test/java/it/example/demo/controller/CityControllerV1Test.java
// ============================================================================

