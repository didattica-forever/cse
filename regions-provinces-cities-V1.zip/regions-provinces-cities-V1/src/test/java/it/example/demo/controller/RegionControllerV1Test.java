// ============================================================================
// File: src/test/java/it/example/demo/controller/RegionControllerV1Test.java
// ============================================================================

package it.example.demo.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import it.example.demo.dto.RegionDTO;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class RegionControllerV1Test {

    private static final Logger logger = LoggerFactory.getLogger(RegionControllerV1Test.class);

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void shouldReturnAllRegions() throws Exception {
        MvcResult result = mockMvc.perform(get("/regions")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String json = result.getResponse().getContentAsString();

        List<RegionDTO> regions = objectMapper.readValue(json, new TypeReference<List<RegionDTO>>() {});

        assertEquals(20, regions.size(), "La lista delle regioni deve contenere 20 elementi");

        // Logging del risultato dopo le asserzioni
        logger.info("GET /regions -> total: {}", regions.size());
        if (!regions.isEmpty()) {
            logger.info("Primo elemento: id={}, name={}", regions.get(0).getId(), regions.get(0).getName());
        }
    }

    @Test
    void shouldReturnRegionById() throws Exception {
        MvcResult result = mockMvc.perform(get("/regions/{id}", 1)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String json = result.getResponse().getContentAsString();
        RegionDTO region = objectMapper.readValue(json, RegionDTO.class);

        assertThat(region).isNotNull();
        assertThat(region.getId()).isEqualTo(1);

        logger.info("GET /regions/1 -> id={}, name={}", region.getId(), region.getName());
    }

    @Test
    void shouldReturn404ForUnknownRegion() throws Exception {
        MvcResult result = mockMvc.perform(get("/regions/{id}", 9999)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andReturn();

        String body = result.getResponse().getContentAsString();

        // Il body può essere JSON "sporco" default di Spring, qui non si fa parsing
        logger.info("GET /regions/9999 -> 404 body: {}", body);
    }
}

// ============================================================================
// File: src/test/java/it/example/demo/controller/ProvinceControllerV1Test.java
// ============================================================================

