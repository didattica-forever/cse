package it.example.demo.repository;

import it.example.demo.entity.City;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
public class CityRepositoryTest {

    @Autowired
    private CityRepository cityRepository;

    @Test
    void shouldLoadAllCities() {
        long count = cityRepository.count();
        assertEquals(7999, count, "Il numero di comuni deve essere 7999");
    }

    @Test
    void shouldFindCityById() {
        Optional<City> maybe = cityRepository.findById(10001);
        assertTrue(maybe.isPresent(), "Il comune con id=10001 deve esistere");
    }
}

// ============================================================================
// File: src/test/java/it/example/demo/service/RegionServiceV1Test.java
// ============================================================================

