// ============================================================================
// File: src/test/java/it/example/demo/repository/ProvinceRepositoryTest.java
// ============================================================================

package it.example.demo.repository;

import it.example.demo.entity.Province;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
public class ProvinceRepositoryTest {

    @Autowired
    private ProvinceRepository provinceRepository;

    @Test
    void shouldLoadAllProvinces() {
        long count = provinceRepository.count();
        assertEquals(110, count, "Il numero di province deve essere 110");
    }

    @Test
    void shouldFindProvinceById() {
        Optional<Province> maybe = provinceRepository.findById(101);
        assertTrue(maybe.isPresent(), "La provincia con id=101 deve esistere");
    }
}

// ============================================================================
// File: src/test/java/it/example/demo/repository/CityRepositoryTest.java
// ============================================================================

