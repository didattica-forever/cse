package it.example.demo.repository;

import it.example.demo.entity.Region;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
public class RegionRepositoryTest {

    @Autowired
    private RegionRepository regionRepository;

    @Test
    void shouldLoadAllRegions() {
        long count = regionRepository.count();
        assertEquals(20, count, "Il numero di regioni deve essere 20");
        System.out.println("Sono state trovate "+count+" regioni");
    }

    @Test
    void shouldFindRegionById() {
        Optional<Region> maybe = regionRepository.findById(1);
        assertTrue(maybe.isPresent(), "La regione con id=1 deve esistere");
        System.out.println(maybe.get());
    }
}