package it.example.demo.service;

import it.example.demo.dto.CityDTO;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class CityServiceV1Test {

    @Autowired
    private CityService cityService;

    @Test
    void shouldReturnAllCities() {
        List<CityDTO> cities = cityService.getAllCities();
        assertEquals(7999, cities.size(), "La lista dei comuni deve contenere 7999 elementi");
    }

    @Test
    void shouldReturnCityById() {
        CityDTO city = cityService.getCityById(10001);
        assertNotNull(city);
        assertEquals(10001, city.getId());
    }

    @Test
    void shouldThrow404ForUnknownCity() {
        assertThrows(ResponseStatusException.class,
                () -> cityService.getCityById(999999),
                "Per un comune inesistente ci si aspetta un 404");
    }
}