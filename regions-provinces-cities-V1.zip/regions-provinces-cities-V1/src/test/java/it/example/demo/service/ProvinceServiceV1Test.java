package it.example.demo.service;

import it.example.demo.dto.ProvinceDTO;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class ProvinceServiceV1Test {

    @Autowired
    private ProvinceService provinceService;

    @Test
    void shouldReturnAllProvinces() {
        List<ProvinceDTO> provinces = provinceService.getAllProvinces();
        assertEquals(110, provinces.size(), "La lista delle province deve contenere 110 elementi");
    }

    @Test
    void shouldReturnProvinceById() {
        ProvinceDTO province = provinceService.getProvinceById(101);
        assertNotNull(province);
        assertEquals(101, province.getId());
    }

    @Test
    void shouldThrow404ForUnknownProvince() {
        assertThrows(ResponseStatusException.class,
                () -> provinceService.getProvinceById(9999),
                "Per una provincia inesistente ci si aspetta un 404");
    }
}

// ============================================================================
// File: src/test/java/it/example/demo/service/CityServiceV1Test.java
// ============================================================================

