package it.example.demo.service;

import it.example.demo.dto.RegionDTO;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class RegionServiceV1Test {

    @Autowired
    private RegionService regionService;

    @Test
    void shouldReturnAllRegions() {
        List<RegionDTO> regions = regionService.getAllRegions();
        assertEquals(20, regions.size(), "La lista delle regioni deve contenere 20 elementi");
        regions.forEach(System.out::println);
    }

    @Test
    void shouldReturnRegionById() {
        RegionDTO region = regionService.getRegionById(1);
        assertNotNull(region);
        assertEquals(1, region.getId());
    }

    @Test
    void shouldThrow404ForUnknownRegion() {
        assertThrows(ResponseStatusException.class,
                () -> regionService.getRegionById(9999),
                "Per una regione inesistente ci si aspetta un 404");
    }
}

// ============================================================================
// File: src/test/java/it/example/demo/service/ProvinceServiceV1Test.java
// ============================================================================

