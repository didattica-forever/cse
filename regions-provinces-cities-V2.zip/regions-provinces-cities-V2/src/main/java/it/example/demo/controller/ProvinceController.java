package it.example.demo.controller;

import it.example.demo.dto.ProvinceDTO;
import it.example.demo.service.ProvinceService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/provinces")
public class ProvinceController {

    private final ProvinceService provinceService;

    public ProvinceController(ProvinceService provinceService) {
        this.provinceService = provinceService;
    }

    @GetMapping
    public List<ProvinceDTO> getAllProvinces(
            @RequestParam(name = "regionId", required = false) Integer regionId,
            @RequestParam(name = "name", required = false) String name) {
        return provinceService.getProvinces(regionId, name);
    }

    @GetMapping("/{id}")
    public ProvinceDTO getProvinceById(@PathVariable Integer id) {
        return provinceService.getProvinceById(id);
    }
}

