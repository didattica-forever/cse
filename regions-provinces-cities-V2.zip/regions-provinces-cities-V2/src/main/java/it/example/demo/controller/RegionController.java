package it.example.demo.controller;

import it.example.demo.dto.RegionDTO;
import it.example.demo.service.RegionService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/regions")
public class RegionController {

    private final RegionService regionService;

    public RegionController(RegionService regionService) {
        this.regionService = regionService;
    }

    @GetMapping
    public List<RegionDTO> getAllRegions(
            @RequestParam(name = "name", required = false) String name) {
        return regionService.getRegions(name);
    }

    @GetMapping("/{id}")
    public RegionDTO getRegionById(@PathVariable Integer id) {
        return regionService.getRegionById(id);
    }
}
