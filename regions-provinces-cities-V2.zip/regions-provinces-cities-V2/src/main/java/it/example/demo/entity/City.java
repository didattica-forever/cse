package it.example.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "comuni")
public class City {

    @Id
    @Column(name = "id")
    private Integer id;

    @Column(name = "id_regione", nullable = false)
    private Integer idRegione;

    @Column(name = "id_provincia", nullable = false)
    private Integer idProvincia;

    @Column(name = "nome", nullable = false)
    private String nome;

    @Column(name = "capoluogo_provincia", nullable = false)
    private Integer capoluogoProvincia;

    @Column(name = "codice_catastale")
    private String codiceCatastale;

    @Column(name = "latitudine")
    private Double latitudine;

    @Column(name = "longitudine")
    private Double longitudine;

    public City() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getIdRegione() {
        return idRegione;
    }

    public void setIdRegione(Integer idRegione) {
        this.idRegione = idRegione;
    }

    public Integer getIdProvincia() {
        return idProvincia;
    }

    public void setIdProvincia(Integer idProvincia) {
        this.idProvincia = idProvincia;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getCapoluogoProvincia() {
        return capoluogoProvincia;
    }

    public void setCapoluogoProvincia(Integer capoluogoProvincia) {
        this.capoluogoProvincia = capoluogoProvincia;
    }

    public String getCodiceCatastale() {
        return codiceCatastale;
    }

    public void setCodiceCatastale(String codiceCatastale) {
        this.codiceCatastale = codiceCatastale;
    }

    public Double getLatitudine() {
        return latitudine;
    }

    public void setLatitudine(Double latitudine) {
        this.latitudine = latitudine;
    }

    public Double getLongitudine() {
        return longitudine;
    }

    public void setLongitudine(Double longitudine) {
        this.longitudine = longitudine;
    }

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("City [id=").append(id).append(", idRegione=").append(idRegione).append(", idProvincia=")
				.append(idProvincia).append(", nome=").append(nome).append(", capoluogoProvincia=")
				.append(capoluogoProvincia).append(", codiceCatastale=").append(codiceCatastale).append(", latitudine=")
				.append(latitudine).append(", longitudine=").append(longitudine).append("]");
		return builder.toString();
	}
}
