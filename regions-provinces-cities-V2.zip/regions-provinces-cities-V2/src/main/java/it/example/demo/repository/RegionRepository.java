package it.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import it.example.demo.entity.Region;

public interface RegionRepository extends JpaRepository<Region, Integer> {

	/**
	 * @SEE https://docs.spring.io/spring-data/jpa/docs/current-SNAPSHOT/reference/html/#jpa.query-methods
	 * @param nome
	 * @return
	 */
    List<Region> findByNomeContainingIgnoreCase(String nome); // trova tutte le regioni con il nome che assomiglia a
}
