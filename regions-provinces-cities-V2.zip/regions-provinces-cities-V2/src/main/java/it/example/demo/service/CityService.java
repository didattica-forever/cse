package it.example.demo.service;

import it.example.demo.dto.CityDTO;
import it.example.demo.entity.City;
import it.example.demo.exception.CityNotFoundException;
import it.example.demo.mapper.CityMapper;
import it.example.demo.repository.CityRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class CityService {

    private final CityRepository cityRepository;

    public CityService(CityRepository cityRepository) {
        this.cityRepository = cityRepository;
    }

    public List<CityDTO> getCities(Integer regionId, Integer provinceId, String name) {
        List<City> entities;

        boolean hasRegion = regionId != null;
        boolean hasProvince = provinceId != null;
        boolean hasName = name != null && !name.isBlank();

        if (!hasRegion && !hasProvince && !hasName) {
            entities = cityRepository.findAll();
        } else if (hasRegion && !hasProvince && !hasName) {
            entities = cityRepository.findByIdRegione(regionId);
        } else if (!hasRegion && hasProvince && !hasName) {
            entities = cityRepository.findByIdProvincia(provinceId);
        } else if (!hasRegion && !hasProvince && hasName) {
            entities = cityRepository.findByNomeContainingIgnoreCase(name);
        } else if (hasRegion && hasProvince && !hasName) {
            entities = cityRepository.findByIdRegioneAndIdProvincia(regionId, provinceId);
        } else if (hasRegion && !hasProvince && hasName) {
            entities = cityRepository.findByIdRegioneAndNomeContainingIgnoreCase(regionId, name);
        } else if (!hasRegion && hasProvince && hasName) {
            entities = cityRepository.findByIdProvinciaAndNomeContainingIgnoreCase(provinceId, name);
        } else {
            entities = cityRepository.findByIdRegioneAndIdProvinciaAndNomeContainingIgnoreCase(regionId, provinceId, name);
        }

        return entities.stream()
                .map(CityMapper::toDto)
                .toList();
    }

    public CityDTO getCityById(Integer id) {
        City city = cityRepository.findById(id)
                .orElseThrow(() -> new CityNotFoundException(id));
        return CityMapper.toDto(city);
    }
}
