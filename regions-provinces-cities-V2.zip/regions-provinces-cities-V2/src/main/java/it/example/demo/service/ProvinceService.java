package it.example.demo.service;

import it.example.demo.dto.ProvinceDTO;
import it.example.demo.entity.Province;
import it.example.demo.exception.ProvinceNotFoundException;
import it.example.demo.mapper.ProvinceMapper;
import it.example.demo.repository.ProvinceRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class ProvinceService {

    private final ProvinceRepository provinceRepository;

    public ProvinceService(ProvinceRepository provinceRepository) {
        this.provinceRepository = provinceRepository;
    }

    public List<ProvinceDTO> getProvinces(Integer regionId, String name) {
        List<Province> entities;

        boolean hasRegion = regionId != null;
        boolean hasName = name != null && !name.isBlank();

        if (!hasRegion && !hasName) {
            entities = provinceRepository.findAll();
        } else if (hasRegion && !hasName) {
            entities = provinceRepository.findByIdRegione(regionId);
        } else if (!hasRegion && hasName) {
            entities = provinceRepository.findByNomeContainingIgnoreCase(name);
        } else {
            entities = provinceRepository.findByIdRegioneAndNomeContainingIgnoreCase(regionId, name);
        }

        return entities.stream()
                .map(ProvinceMapper::toDto)
                .toList();
    }

    public ProvinceDTO getProvinceById(Integer id) {
        Province province = provinceRepository.findById(id)
                .orElseThrow(() -> new ProvinceNotFoundException(id));
        return ProvinceMapper.toDto(province);
    }
}

