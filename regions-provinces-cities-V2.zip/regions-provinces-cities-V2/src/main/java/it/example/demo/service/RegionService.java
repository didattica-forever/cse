package it.example.demo.service;

import it.example.demo.dto.RegionDTO;
import it.example.demo.entity.Region;
import it.example.demo.exception.RegionNotFoundException;
import it.example.demo.mapper.RegionMapper;
import it.example.demo.repository.RegionRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class RegionService {

    private final RegionRepository regionRepository;

    public RegionService(RegionRepository regionRepository) {
        this.regionRepository = regionRepository;
    }

    public List<RegionDTO> getRegions(String name) {
        List<Region> entities;

        if (name == null || name.isBlank()) {
            entities = regionRepository.findAll();
        } else {
            entities = regionRepository.findByNomeContainingIgnoreCase(name);
        }

        return entities.stream()
                .map(RegionMapper::toDto)
                .toList();
    }

    public RegionDTO getRegionById(Integer id) {
        Region region = regionRepository.findById(id)
                .orElseThrow(() -> new RegionNotFoundException(id));
        return RegionMapper.toDto(region);
    }
}

