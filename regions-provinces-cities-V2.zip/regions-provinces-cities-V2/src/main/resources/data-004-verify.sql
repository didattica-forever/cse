-- Script di verifica integrità
SELECT 'Regioni' as Tbl, COUNT(*) as Tot FROM regioni;
SELECT 'Province' as Tbl, COUNT(*) as Tot FROM province;
SELECT 'Comuni' as Tbl, COUNT(*) as Tot FROM comuni;
