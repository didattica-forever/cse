# curl Query - V1


**6** Endpoint disponibili:

* `/regions`, `/regions/{id}`
* `/provinces`, `/provinces/{id}`
* `/cities`, `/cities/{id}`

Porta: **8080** (come in application.properties)

## REGIONS

```bash
# Lista regioni
curl -s http://localhost:8080/regions | jq

# Dettaglio regione
curl -s http://localhost:8080/regions/1 | jq

# error 404 comportamento “sporco”
curl -i http://localhost:8080/regions/999
```
## PROVINCES

```bash
# 2.1 — Lista province
curl -s http://localhost:8080/provinces | jq

# Dettaglio provincia
curl -s http://localhost:8080/provinces/101 | jq
```

## CITIES

```bash
# Lista comuni
curl -s http://localhost:8080/cities | jq

# Dettaglio comune
curl -s http://localhost:8080/cities/10001 | jq
```


## altre query

```bash
# Stampa solo i nomi delle regioni
curl -s http://localhost:8080/regions | jq '.[].name'

# Conta quante province vengono restituite
curl -s http://localhost:8080/provinces | jq 'length'

# Mostra solo i capoluoghi
curl -s http://localhost:8080/cities \
  | jq '[.[] | select(.isProvinceCapital == true)]'

# Stampare nome + sigla provincia in tabella
curl -s http://localhost:8080/provinces \
  | jq -r '.[] | "\(.id)\t\(.name)\t\(.carPlateCode)"'
```

