package it.example.demo.controller;

import it.example.demo.dto.PagedResponse;
import it.example.demo.dto.ProvinceDTO;
import it.example.demo.service.ProvinceService;
import it.example.demo.util.PaginationHelper;
import org.springframework.data.domain.Page;
import org.springframework.hateoas.Link;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("/provinces")
public class ProvinceController {

    private final ProvinceService provinceService;

    public ProvinceController(ProvinceService provinceService) {
        this.provinceService = provinceService;
    }

    @GetMapping
    public ResponseEntity<?> getAllProvinces(
            @RequestParam(name = "regionId", required = false) Integer regionId,
            @RequestParam(name = "name", required = false) String name,
            @RequestParam(name = "page", required = false) Integer pageParam,
            @RequestParam(name = "size", required = false) Integer sizeParam) {

        boolean paginationRequested = pageParam != null || sizeParam != null;

        if (!paginationRequested) {
            List<ProvinceDTO> provinces = provinceService.getProvinces(regionId, name);
            return ResponseEntity.ok(provinces);
        }

        int page = pageParam != null ? pageParam : 0;
        int size = sizeParam != null ? sizeParam : 20;

        Page<ProvinceDTO> pageData = provinceService.getProvincesPage(regionId, name, page, size);

        Link selfLink = linkTo(methodOn(ProvinceController.class)
                .getAllProvinces(regionId, name, page, size))
                .withSelfRel();

        Link nextLink = null;
        if (pageData.getNumber() < pageData.getTotalPages() - 1) {
            nextLink = linkTo(methodOn(ProvinceController.class)
                    .getAllProvinces(regionId, name, page + 1, size))
                    .withRel("next");
        }

        Link prevLink = null;
        if (pageData.getNumber() > 0) {
            prevLink = linkTo(methodOn(ProvinceController.class)
                    .getAllProvinces(regionId, name, page - 1, size))
                    .withRel("prev");
        }

        PagedResponse<ProvinceDTO> response = PaginationHelper.buildPagedResponse(pageData, selfLink, nextLink, prevLink);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/{id}")
    public ProvinceDTO getProvinceById(@PathVariable Integer id) {
        return provinceService.getProvinceById(id);
    }
}
