package it.example.demo.dto;

public class CityDTO {

    private Integer id;
    private String name;
    private Integer regionId;
    private Integer provinceId;
    private Boolean isProvinceCapital;
    private String cadastralCode;
    private Double latitude;
    private Double longitude;

    public CityDTO() {
    }

    public CityDTO(Integer id,
                   String name,
                   Integer regionId,
                   Integer provinceId,
                   Boolean isProvinceCapital,
                   String cadastralCode,
                   Double latitude,
                   Double longitude) {
        this.id = id;
        this.name = name;
        this.regionId = regionId;
        this.provinceId = provinceId;
        this.isProvinceCapital = isProvinceCapital;
        this.cadastralCode = cadastralCode;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getRegionId() {
        return regionId;
    }

    public void setRegionId(Integer regionId) {
        this.regionId = regionId;
    }

    public Integer getProvinceId() {
        return provinceId;
    }

    public void setProvinceId(Integer provinceId) {
        this.provinceId = provinceId;
    }

    public Boolean getIsProvinceCapital() {
        return isProvinceCapital;
    }

    public void setIsProvinceCapital(Boolean provinceCapital) {
        isProvinceCapital = provinceCapital;
    }

    public String getCadastralCode() {
        return cadastralCode;
    }

    public void setCadastralCode(String cadastralCode) {
        this.cadastralCode = cadastralCode;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }
}
