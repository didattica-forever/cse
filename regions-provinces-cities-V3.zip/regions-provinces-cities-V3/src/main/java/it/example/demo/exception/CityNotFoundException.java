package it.example.demo.exception;

public class CityNotFoundException extends RuntimeException {

    private final Integer id;

    public CityNotFoundException(Integer id) {
        super("City " + id + " not found");
        this.id = id;
    }

    public Integer getId() {
        return id;
    }
}
