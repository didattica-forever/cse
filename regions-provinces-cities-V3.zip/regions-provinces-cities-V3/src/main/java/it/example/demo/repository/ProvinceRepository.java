package it.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import it.example.demo.entity.Province;

public interface ProvinceRepository extends JpaRepository<Province, Integer> {

    List<Province> findByIdRegione(Integer idRegione);

    List<Province> findByNomeContainingIgnoreCase(String nome);

    List<Province> findByIdRegioneAndNomeContainingIgnoreCase(Integer idRegione, String nome);
}
