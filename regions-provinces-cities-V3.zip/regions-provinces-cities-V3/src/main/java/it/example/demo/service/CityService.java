package it.example.demo.service;

import it.example.demo.dto.CityDTO;
import it.example.demo.entity.City;
import it.example.demo.exception.CityNotFoundException;
import it.example.demo.mapper.CityMapper;
import it.example.demo.repository.CityRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CityService {

    private final CityRepository cityRepository;

    public CityService(CityRepository cityRepository) {
        this.cityRepository = cityRepository;
    }

    // V2: lista non paginata
    public List<CityDTO> getCities(Integer regionId, Integer provinceId, String name) {
        List<City> entities = findCities(regionId, provinceId, name);
        return entities.stream()
                .map(CityMapper::toDto)
                .toList();
    }

    // V3: pagina di comuni
    public Page<CityDTO> getCitiesPage(Integer regionId,
                                       Integer provinceId,
                                       String name,
                                       int page,
                                       int size) {
        PageRequest pageable = PageRequest.of(page, size);

        List<City> all = findCities(regionId, provinceId, name);
        int from = page * size;
        if (from >= all.size()) {
            return new PageImpl<>(List.of(), pageable, all.size());
        }
        int to = Math.min(from + size, all.size());
        List<City> slice = all.subList(from, to);

        Page<City> cityPage = new PageImpl<>(slice, pageable, all.size());
        return cityPage.map(CityMapper::toDto);
    }

    private List<City> findCities(Integer regionId, Integer provinceId, String name) {
        boolean hasRegion = regionId != null;
        boolean hasProvince = provinceId != null;
        boolean hasName = name != null && !name.isBlank();

        if (!hasRegion && !hasProvince && !hasName) {
            return cityRepository.findAll();
        } else if (hasRegion && !hasProvince && !hasName) {
            return cityRepository.findByIdRegione(regionId);
        } else if (!hasRegion && hasProvince && !hasName) {
            return cityRepository.findByIdProvincia(provinceId);
        } else if (!hasRegion && !hasProvince && hasName) {
            return cityRepository.findByNomeContainingIgnoreCase(name);
        } else if (hasRegion && hasProvince && !hasName) {
            return cityRepository.findByIdRegioneAndIdProvincia(regionId, provinceId);
        } else if (hasRegion && !hasProvince && hasName) {
            return cityRepository.findByIdRegioneAndNomeContainingIgnoreCase(regionId, name);
        } else if (!hasRegion && hasProvince && hasName) {
            return cityRepository.findByIdProvinciaAndNomeContainingIgnoreCase(provinceId, name);
        } else {
            return cityRepository.findByIdRegioneAndIdProvinciaAndNomeContainingIgnoreCase(regionId, provinceId, name);
        }
    }

    public CityDTO getCityById(Integer id) {
        City city = cityRepository.findById(id)
                .orElseThrow(() -> new CityNotFoundException(id));
        return CityMapper.toDto(city);
    }
}
