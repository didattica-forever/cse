package it.example.demo.service;

import it.example.demo.dto.RegionDTO;
import it.example.demo.entity.Region;
import it.example.demo.exception.RegionNotFoundException;
import it.example.demo.mapper.RegionMapper;
import it.example.demo.repository.RegionRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RegionService {

    private final RegionRepository regionRepository;

    public RegionService(RegionRepository regionRepository) {
        this.regionRepository = regionRepository;
    }

    // V2: lista non paginata (comportamento legacy)
    public List<RegionDTO> getRegions(String name) {
        List<Region> entities = findRegions(name);
        return entities.stream()
                .map(RegionMapper::toDto)
                .toList();
    }

    // V3: pagina di regioni (paginazione + filtri)
    public Page<RegionDTO> getRegionsPage(String name, int page, int size) {
        PageRequest pageable = PageRequest.of(page, size);

        List<Region> all = findRegions(name);
        int from = page * size;
        if (from >= all.size()) {
            return new PageImpl<>(List.of(), pageable, all.size());
        }
        int to = Math.min(from + size, all.size());
        List<Region> slice = all.subList(from, to);

        Page<Region> regionPage = new PageImpl<>(slice, pageable, all.size());
        return regionPage.map(RegionMapper::toDto);
    }

    private List<Region> findRegions(String name) {
        if (name == null || name.isBlank()) {
            return regionRepository.findAll();
        }
        return regionRepository.findByNomeContainingIgnoreCase(name);
    }

    public RegionDTO getRegionById(Integer id) {
        Region region = regionRepository.findById(id)
                .orElseThrow(() -> new RegionNotFoundException(id));
        return RegionMapper.toDto(region);
    }
}
