package it.example.demo.dto;

public class RegionDTO {

    private Integer id;
    private String name;
    private String url;
    private Double latitude;
    private Double longitude;

    public RegionDTO() {
    }

    public RegionDTO(Integer id, String name, String url, Double latitude, Double longitude) {
        this.id = id;
        this.name = name;
        this.url = url;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }
}
