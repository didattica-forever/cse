package it.example.demo.exception;

public class ProvinceNotFoundException extends RuntimeException {

    private final Integer id;

    public ProvinceNotFoundException(Integer id) {
        super("Province " + id + " not found");
        this.id = id;
    }

    public Integer getId() {
        return id;
    }
}
