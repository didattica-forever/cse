package it.example.demo.exception;

public class RegionNotFoundException extends RuntimeException {

    private final Integer id;

    public RegionNotFoundException(Integer id) {
        super("Region " + id + " not found");
        this.id = id;
    }

    public Integer getId() {
        return id;
    }
}
