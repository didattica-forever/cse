package it.example.demo.repository;

import it.example.demo.entity.City;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CityRepository extends JpaRepository<City, Integer> {

    List<City> findByIdRegione(Integer idRegione);

    List<City> findByIdProvincia(Integer idProvincia);

    List<City> findByNomeContainingIgnoreCase(String nome);

    List<City> findByIdRegioneAndIdProvincia(Integer idRegione, Integer idProvincia);

    List<City> findByIdRegioneAndNomeContainingIgnoreCase(Integer idRegione, String nome);

    List<City> findByIdProvinciaAndNomeContainingIgnoreCase(Integer idProvincia, String nome);

    List<City> findByIdRegioneAndIdProvinciaAndNomeContainingIgnoreCase(Integer idRegione, Integer idProvincia, String nome);
}

