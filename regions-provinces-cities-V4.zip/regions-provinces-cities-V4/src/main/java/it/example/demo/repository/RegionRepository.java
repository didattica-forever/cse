package it.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import it.example.demo.entity.Region;

public interface RegionRepository extends JpaRepository<Region, Integer> {

    List<Region> findByNomeContainingIgnoreCase(String nome);
}
