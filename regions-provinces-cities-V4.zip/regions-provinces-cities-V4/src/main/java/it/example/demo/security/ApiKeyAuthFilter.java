package it.example.demo.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/**
 * Filtro che verifica la presenza e la validità dell'header X-API-Key
 * sugli endpoint di lista (/regions, /provinces, /cities).
 *
 * - Se la chiave è valida -> imposta un'Authentication nel SecurityContext.
 * - Se la chiave è assente -> non autentica, lascerà generare 401 allo strato Security.
 * - Se la chiave è sbagliata -> risponde direttamente 403 con JSON {"error":"Invalid API-Key"}.
 */
public class ApiKeyAuthFilter extends OncePerRequestFilter {

    private final String expectedApiKey;

    public ApiKeyAuthFilter(String expectedApiKey) {
        this.expectedApiKey = expectedApiKey;
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getServletPath();
        // Il filtro si applica solo agli endpoint di lista
        return !("/regions".equals(path) || "/provinces".equals(path) || "/cities".equals(path));
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {

        String apiKeyHeader = request.getHeader("X-API-Key");

        // Assenza totale di header: non si autentica, si lascia che Security generi 401
        if (apiKeyHeader == null || apiKeyHeader.isBlank()) {
            filterChain.doFilter(request, response);
            return;
        }

        // Header presente ma valore errato: 403 Forbidden immediato
        if (!expectedApiKey.equals(apiKeyHeader)) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            response.setContentType("application/json");
            response.getWriter().write("{\"error\":\"Invalid API-Key\"}");
            return;
        }

        // Header presente e corretto: si autentica l'utente "apiKeyUser"
        Authentication authentication = new UsernamePasswordAuthenticationToken(
                "apiKeyUser",
                null,
                java.util.List.of() // niente ruoli per ora
        );
        SecurityContextHolder.getContext().setAuthentication(authentication);

        filterChain.doFilter(request, response);
    }
}
