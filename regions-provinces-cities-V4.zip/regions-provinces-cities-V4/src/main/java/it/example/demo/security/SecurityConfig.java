package it.example.demo.security;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
public class SecurityConfig {

    @Value("${app.security.api-key}")
    private String apiKey;

    @Bean
    public ApiKeyAuthFilter apiKeyAuthFilter() {
        return new ApiKeyAuthFilter(apiKey);
    }

    @Bean
    public ApiKeyAuthenticationEntryPoint apiKeyAuthenticationEntryPoint() {
        return new ApiKeyAuthenticationEntryPoint();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http
                // Niente sessione, niente form login, CSRF disabilitato per semplicità didattica
                .csrf(csrf -> csrf.disable())
                .httpBasic(Customizer.withDefaults())
                .formLogin(form -> form.disable())
                .logout(logout -> logout.disable())

                // Gestione eccezioni di autenticazione
                .exceptionHandling(ex -> ex
                        .authenticationEntryPoint(apiKeyAuthenticationEntryPoint())
                )

                // Regole di autorizzazione
                .authorizeHttpRequests(auth -> auth
                        // Endpoint di dettaglio: pubblici
                        .requestMatchers(HttpMethod.GET, "/regions/*").permitAll()
                        .requestMatchers(HttpMethod.GET, "/provinces/*").permitAll()
                        .requestMatchers(HttpMethod.GET, "/cities/*").permitAll()

                        // Endpoint di lista: richiedono API key
                        .requestMatchers(HttpMethod.GET, "/regions").authenticated()
                        .requestMatchers(HttpMethod.GET, "/provinces").authenticated()
                        .requestMatchers(HttpMethod.GET, "/cities").authenticated()

                        // Tutto il resto: consentito (o da regolare se necessario)
                        .anyRequest().permitAll()
                )

                // Inserimento del filtro custom prima del filtro standard di username/password
                .addFilterBefore(apiKeyAuthFilter(), UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}
