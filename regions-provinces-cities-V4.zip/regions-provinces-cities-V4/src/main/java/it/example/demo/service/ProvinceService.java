package it.example.demo.service;

import it.example.demo.dto.ProvinceDTO;
import it.example.demo.entity.Province;
import it.example.demo.exception.ProvinceNotFoundException;
import it.example.demo.mapper.ProvinceMapper;
import it.example.demo.repository.ProvinceRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProvinceService {

    private final ProvinceRepository provinceRepository;

    public ProvinceService(ProvinceRepository provinceRepository) {
        this.provinceRepository = provinceRepository;
    }

    // V2: lista non paginata
    public List<ProvinceDTO> getProvinces(Integer regionId, String name) {
        List<Province> entities = findProvinces(regionId, name);
        return entities.stream()
                .map(ProvinceMapper::toDto)
                .toList();
    }

    // V3: pagina di province
    public Page<ProvinceDTO> getProvincesPage(Integer regionId, String name, int page, int size) {
        PageRequest pageable = PageRequest.of(page, size);

        List<Province> all = findProvinces(regionId, name);
        int from = page * size;
        if (from >= all.size()) {
            return new PageImpl<>(List.of(), pageable, all.size());
        }
        int to = Math.min(from + size, all.size());
        List<Province> slice = all.subList(from, to);

        Page<Province> provincePage = new PageImpl<>(slice, pageable, all.size());
        return provincePage.map(ProvinceMapper::toDto);
    }

    private List<Province> findProvinces(Integer regionId, String name) {
        boolean hasRegion = regionId != null;
        boolean hasName = name != null && !name.isBlank();

        if (!hasRegion && !hasName) {
            return provinceRepository.findAll();
        } else if (hasRegion && !hasName) {
            return provinceRepository.findByIdRegione(regionId);
        } else if (!hasRegion && hasName) {
            return provinceRepository.findByNomeContainingIgnoreCase(name);
        } else {
            return provinceRepository.findByIdRegioneAndNomeContainingIgnoreCase(regionId, name);
        }
    }

    public ProvinceDTO getProvinceById(Integer id) {
        Province province = provinceRepository.findById(id)
                .orElseThrow(() -> new ProvinceNotFoundException(id));
        return ProvinceMapper.toDto(province);
    }
}
