#!/usr/bin/env bash

# Script di test per API V3 Regioni/Province/Comuni
# Verifica:
# - comportamento legacy (senza page/size)
# - paginazione (page, size)
# - presenza link HATEOAS: _links.self, _links.next, _links.prev

# Base URL dell'API; può essere sovrascritto passando un argomento allo script
BASE_URL="${1:-http://localhost:8080}"

echo "Uso BASE_URL=${BASE_URL}"
echo

# ----------------------------------------
# Sezione 1: Comportamento legacy (senza page/size)
# ----------------------------------------

echo "=== 1. Comportamento legacy V1/V2 (senza page/size) ==="

echo
echo "# 1.1 GET /regions (lista semplice, nessun wrapper paginato)"
curl -s "${BASE_URL}/regions" | jq '.[0:3]'

echo
echo "# 1.2 GET /provinces (lista semplice, conteggio elementi)"
curl -s "${BASE_URL}/provinces" | jq 'length'

echo
echo "# 1.3 GET /cities (lista semplice, solo conteggio)"
curl -s "${BASE_URL}/cities" | jq 'length'

# ----------------------------------------
# Sezione 2: Paginazione /regions (page, size, HATEOAS)
# ----------------------------------------

echo
echo "=== 2. Paginazione su /regions ==="

echo
echo "# 2.1 GET /regions?page=0&size=5 (pagina 0, dimensione 5)"
curl -s "${BASE_URL}/regions?page=0&size=5" | jq '{page, size, totalElements, totalPages, links: ._links}'

echo
echo "# 2.2 GET /regions?page=1&size=5 (pagina 1, dimensione 5)"
curl -s "${BASE_URL}/regions?page=1&size=5" | jq '{page, size, totalElements, totalPages, links: ._links}'

echo
echo "# 2.3 GET /regions?name=lom&page=0&size=2 (filtro + paginazione)"
curl -s "${BASE_URL}/regions?name=lom&page=0&size=2" | jq '{page, size, totalElements, totalPages, content, links: ._links}'

# ----------------------------------------
# Sezione 3: Paginazione /provinces con filtri
# ----------------------------------------

echo
echo "=== 3. Paginazione su /provinces con filtri ==="

echo
echo "# 3.1 GET /provinces?page=0&size=10"
curl -s "${BASE_URL}/provinces?page=0&size=10" | jq '{page, size, totalElements, totalPages, content: .content[0:3], links: ._links}'

echo
echo "# 3.2 GET /provinces?regionId=1&page=0&size=5 (province della regione 1, paginato)"
curl -s "${BASE_URL}/provinces?regionId=1&page=0&size=5" | jq '{page, size, totalElements, totalPages, content: .content, links: ._links}'

echo
echo "# 3.3 GET /provinces?regionId=1&name=to&page=0&size=5 (AND logico + paginazione)"
curl -s "${BASE_URL}/provinces?regionId=1&name=to&page=0&size=5" | jq '{page, size, totalElements, totalPages, content: .content, links: ._links}'

# ----------------------------------------
# Sezione 4: Paginazione /cities con combinazioni di filtri
# ----------------------------------------

echo
echo "=== 4. Paginazione su /cities ==="

echo
echo "# 4.1 GET /cities?page=0&size=20 (prima pagina comuni)"
curl -s "${BASE_URL}/cities?page=0&size=20" | jq '{page, size, totalElements, totalPages, sample: .content[0:3], links: ._links}'

echo
echo "# 4.2 GET /cities?page=1&size=20 (seconda pagina comuni)"
curl -s "${BASE_URL}/cities?page=1&size=20" | jq '{page, size, totalElements, totalPages, sample: .content[0:3], links: ._links}'

echo
echo "# 4.3 GET /cities?provinceId=101&page=0&size=10 (comuni di una provincia, paginati)"
curl -s "${BASE_URL}/cities?provinceId=101&page=0&size=10" | jq '{page, size, totalElements, totalPages, sample: .content[0:5], links: ._links}'

echo
echo "# 4.4 GET /cities?regionId=1&name=tor&page=0&size=5 (filtro multiplo + paginazione)"
curl -s "${BASE_URL}/cities?regionId=1&name=tor&page=0&size=5" | jq '{page, size, totalElements, totalPages, content: .content, links: ._links}'

echo
echo "# 4.5 GET /cities?regionId=1&provinceId=101&name=tor&page=0&size=5 (AND completo + paginazione)"
curl -s "${BASE_URL}/cities?regionId=1&provinceId=101&name=tor&page=0&size=5" | jq '{page, size, totalElements, totalPages, content: .content, links: ._links}'

# ----------------------------------------
# Sezione 5: Verifica HATEOAS (self, next, prev)
# ----------------------------------------

echo
echo "=== 5. Verifica HATEOAS (_links.self, _links.next, _links.prev) ==="

echo
echo "# 5.1 /cities pagina 0 (self e next attesi, prev assente)"
curl -s "${BASE_URL}/cities?page=0&size=10" | jq '._links'

echo
echo "# 5.2 /cities pagina 1 (self, next e prev possibili, dipende da totalPages)"
curl -s "${BASE_URL}/cities?page=1&size=10" | jq '._links'

echo
echo "# 5.3 /cities ultima pagina (self e prev attesi, next assente)"
# Calcolo dell'ultima pagina (esegue due chiamate: una per totalPages, una per l'ultima pagina)
TOTAL_PAGES=$(curl -s "${BASE_URL}/cities?page=0&size=10" | jq '.totalPages')
LAST_PAGE=$((TOTAL_PAGES - 1))

echo "#     totalPages=${TOTAL_PAGES}, lastPage=${LAST_PAGE}"
curl -s "${BASE_URL}/cities?page=${LAST_PAGE}&size=10" | jq '._links'

echo
echo "=== Fine test V3 ==="
