```bsh

#!/usr/bin/env bash

# Base URL dell'API V2; può essere sovrascritto passando un argomento allo script
BASE_URL="${1:-http://localhost:8080}"

echo "Usa BASE_URL=${BASE_URL}"
echo

# ----------------------------------------
# Sezione 1: Endpoint V1 (comportamento base, senza filtri)
# ----------------------------------------

echo "=== 1. Verifica comportamento V1 (senza filtri) ==="

# Elenco completo regioni (comportamento identico a V1)
echo
echo "# 1.1 GET /regions (tutte le regioni)"
curl -s "${BASE_URL}/regions" | jq '.'

# Elenco completo province
echo
echo "# 1.2 GET /provinces (tutte le province)"
curl -s "${BASE_URL}/provinces" | jq '. | length as $len | {total: $len}'

# Elenco completo comuni
echo
echo "# 1.3 GET /cities (tutti i comuni)"
curl -s "${BASE_URL}/cities" | jq '. | {total: length}'
# Attenzione: su grandi dataset length può essere costoso; qui è solo demo

# ----------------------------------------
# Sezione 2: Filtri /regions (name)
# ----------------------------------------

echo
echo "=== 2. Filtri su /regions (parametro name) ==="

# Filtro per nome parziale, case-insensitive
echo
echo "# 2.1 GET /regions?name=lom (regioni il cui nome contiene 'lom')"
curl -s "${BASE_URL}/regions?name=lom" | jq '.'

# Caso con nessun risultato atteso
echo
echo "# 2.2 GET /regions?name=zzz (nessuna regione attesa)"
curl -s "${BASE_URL}/regions?name=zzz" | jq '.'

# ----------------------------------------
# Sezione 3: Filtri /provinces (regionId, name)
# ----------------------------------------

echo
echo "=== 3. Filtri su /provinces (regionId, name) ==="

# Tutte le province della regione 1
echo
echo "# 3.1 GET /provinces?regionId=1 (province della regione 1)"
curl -s "${BASE_URL}/provinces?regionId=1" | jq '. | {total: length, items: .[:5]}'

# Tutte le province il cui nome contiene 'tor'
echo
echo "# 3.2 GET /provinces?name=tor (province con 'tor' nel nome)"
curl -s "${BASE_URL}/provinces?name=tor" | jq '.'

# Combinazione AND: regionId + name
echo
echo "# 3.3 GET /provinces?regionId=1&name=to (AND logico tra regionId e name)"
curl -s "${BASE_URL}/provinces?regionId=1&name=to" | jq '.'

# regionId valido ma che non esiste nel dataset: lista vuota, non errore
echo
echo "# 3.4 GET /provinces?regionId=9999 (ID inesistente -> lista vuota, 200 OK)"
curl -s -w "\nHTTP %{http_code}\n" "${BASE_URL}/provinces?regionId=9999" | jq '.'

# ----------------------------------------
# Sezione 4: Filtri /cities (regionId, provinceId, name)
# ----------------------------------------

echo
echo "=== 4. Filtri su /cities (regionId, provinceId, name) ==="

# Tutti i comuni della regione 1
echo
echo "# 4.1 GET /cities?regionId=1"
curl -s "${BASE_URL}/cities?regionId=1" | jq '. | {total: length, sample: .[:5]}'

# Tutti i comuni della provincia 101
echo
echo "# 4.2 GET /cities?provinceId=101"
curl -s "${BASE_URL}/cities?provinceId=101" | jq '. | {total: length, sample: .[:5]}'

# Comuni con 'tor' nel nome
echo
echo "# 4.3 GET /cities?name=tor"
curl -s "${BASE_URL}/cities?name=tor" | jq '.'

# Combinazione AND: regionId + name
echo
echo "# 4.4 GET /cities?regionId=1&name=tor"
curl -s "${BASE_URL}/cities?regionId=1&name=tor" | jq '.'

# Combinazione AND: regionId + provinceId + name
echo
echo "# 4.5 GET /cities?regionId=1&provinceId=101&name=tor"
curl -s "${BASE_URL}/cities?regionId=1&provinceId=101&name=tor" | jq '.'

# Parametri coerenti sintatticamente ma senza match: lista vuota, non errore
echo
echo "# 4.6 GET /cities?regionId=1&provinceId=9999 (coerente sintatticamente ma nessun match)"
curl -s -w "\nHTTP %{http_code}\n" "${BASE_URL}/cities?regionId=1&provinceId=9999" | jq '.'

# ----------------------------------------
# Sezione 5: Error model - 404 Not Found (risorsa inesistente)
# ----------------------------------------

echo
echo "=== 5. Error model: 404 Not Found (risorse inesistenti) ==="

# Regione inesistente
echo
echo "# 5.1 GET /regions/9999 (REGION_NOT_FOUND atteso)"
curl -s -w "\nHTTP %{http_code}\n" "${BASE_URL}/regions/9999" | jq '.'

# Provincia inesistente
echo
echo "# 5.2 GET /provinces/9999 (PROVINCE_NOT_FOUND atteso)"
curl -s -w "\nHTTP %{http_code}\n" "${BASE_URL}/provinces/9999" | jq '.'

# Comune inesistente
echo
echo "# 5.3 GET /cities/999999 (CITY_NOT_FOUND atteso)"
curl -s -w "\nHTTP %{http_code}\n" "${BASE_URL}/cities/999999" | jq '.'

# ----------------------------------------
# Sezione 6: Error model - 400 Bad Request (parametri non numerici)
# ----------------------------------------

echo
echo "=== 6. Error model: 400 Bad Request (parametri non numerici) ==="

# Parametro di path non numerico
echo
echo "# 6.1 GET /cities/abc (ID path non numerico -> 400 INVALID_PARAMETER)"
curl -s -w "\nHTTP %{http_code}\n" "${BASE_URL}/cities/abc" | jq '.'

# Parametro di query non numerico
echo
echo "# 6.2 GET /cities?regionId=abc (query param non numerico -> 400 INVALID_PARAMETER)"
curl -s -w "\nHTTP %{http_code}\n" "${BASE_URL}/cities?regionId=abc" | jq '.'

echo
echo "=== Fine test V2 ==="

```
