package it.example.demo.controller;

import it.example.demo.dto.CityDTO;
import it.example.demo.dto.PagedResponse;
import it.example.demo.service.CityService;
import it.example.demo.util.PaginationHelper;
import org.springframework.data.domain.Page;
import org.springframework.hateoas.Link;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@CrossOrigin(origins = "http://localhost:5000", maxAge = 3600)
@RestController
@RequestMapping("/cities")
public class CityController {

    private final CityService cityService;

    public CityController(CityService cityService) {
        this.cityService = cityService;
    }

    @GetMapping
    public ResponseEntity<?> getAllCities(
            @RequestParam(name = "regionId", required = false) Integer regionId,
            @RequestParam(name = "provinceId", required = false) Integer provinceId,
            @RequestParam(name = "name", required = false) String name,
            @RequestParam(name = "page", required = false) Integer pageParam,
            @RequestParam(name = "size", required = false) Integer sizeParam) {

        boolean paginationRequested = pageParam != null || sizeParam != null;

        if (!paginationRequested) {
            List<CityDTO> cities = cityService.getCities(regionId, provinceId, name);
            return ResponseEntity.ok(cities);
        }

        int page = pageParam != null ? pageParam : 0;
        int size = sizeParam != null ? sizeParam : 20;

        Page<CityDTO> pageData = cityService.getCitiesPage(regionId, provinceId, name, page, size);

        Link selfLink = linkTo(methodOn(CityController.class)
                .getAllCities(regionId, provinceId, name, page, size))
                .withSelfRel();

        Link nextLink = null;
        if (pageData.getNumber() < pageData.getTotalPages() - 1) {
            nextLink = linkTo(methodOn(CityController.class)
                    .getAllCities(regionId, provinceId, name, page + 1, size))
                    .withRel("next");
        }

        Link prevLink = null;
        if (pageData.getNumber() > 0) {
            prevLink = linkTo(methodOn(CityController.class)
                    .getAllCities(regionId, provinceId, name, page - 1, size))
                    .withRel("prev");
        }

        PagedResponse<CityDTO> response = PaginationHelper.buildPagedResponse(pageData, selfLink, nextLink, prevLink);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/{id}")
    public CityDTO getCityById(@PathVariable Integer id) {
        return cityService.getCityById(id);
    }
}
