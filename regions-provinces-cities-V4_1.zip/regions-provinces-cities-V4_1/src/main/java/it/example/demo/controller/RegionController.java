package it.example.demo.controller;

import it.example.demo.dto.PagedResponse;
import it.example.demo.dto.RegionDTO;
import it.example.demo.service.RegionService;
import it.example.demo.util.PaginationHelper;
import org.springframework.data.domain.Page;
import org.springframework.hateoas.Link;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("/regions")
public class RegionController {

    private final RegionService regionService;

    public RegionController(RegionService regionService) {
        this.regionService = regionService;
    }

    @GetMapping
    public ResponseEntity<?> getAllRegions(
            @RequestParam(name = "name", required = false) String name,
            @RequestParam(name = "page", required = false) Integer pageParam,
            @RequestParam(name = "size", required = false) Integer sizeParam) {

        boolean paginationRequested = pageParam != null || sizeParam != null;

        if (!paginationRequested) {
            List<RegionDTO> regions = regionService.getRegions(name);
            return ResponseEntity.ok(regions);
        }

        int page = pageParam != null ? pageParam : 0;
        int size = sizeParam != null ? sizeParam : 20;

        Page<RegionDTO> pageData = regionService.getRegionsPage(name, page, size);

        Link selfLink = linkTo(methodOn(RegionController.class)
                .getAllRegions(name, page, size))
                .withSelfRel();

        Link nextLink = null;
        if (pageData.getNumber() < pageData.getTotalPages() - 1) {
            nextLink = linkTo(methodOn(RegionController.class)
                    .getAllRegions(name, page + 1, size))
                    .withRel("next");
        }

        Link prevLink = null;
        if (pageData.getNumber() > 0) {
            prevLink = linkTo(methodOn(RegionController.class)
                    .getAllRegions(name, page - 1, size))
                    .withRel("prev");
        }

        PagedResponse<RegionDTO> response = PaginationHelper.buildPagedResponse(pageData, selfLink, nextLink, prevLink);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/{id}")
    public RegionDTO getRegionById(@PathVariable Integer id) {
        return regionService.getRegionById(id);
    }
}
