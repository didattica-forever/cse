package it.example.demo.mapper;

import it.example.demo.dto.CityDTO;
import it.example.demo.entity.City;

public final class CityMapper {

    private CityMapper() {
    }

    public static CityDTO toDto(City entity) {
        if (entity == null) {
            return null;
        }
        boolean isCapital = entity.getCapoluogoProvincia() != null
                && entity.getCapoluogoProvincia() != 0;

        return new CityDTO(
                entity.getId(),
                entity.getNome(),
                entity.getIdRegione(),
                entity.getIdProvincia(),
                isCapital,
                entity.getCodiceCatastale(),
                entity.getLatitudine(),
                entity.getLongitudine()
        );
    }
}
