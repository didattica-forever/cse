package it.example.demo.security;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.www.BasicAuthenticationEntryPoint;

import java.io.IOException;

/**
 * Entry point per Basic Auth.
 * V4_1 richiede:
 *  - 401 Unauthorized
 *  - header: WWW-Authenticate: Basic realm="demo"
 */
public class BasicAuthEntryPoint extends BasicAuthenticationEntryPoint {

    @Override
    public void commence(HttpServletRequest request,
                         HttpServletResponse response,
                         AuthenticationException authEx) throws IOException {

        response.addHeader("WWW-Authenticate", "Basic realm=\"" + getRealmName() + "\"");
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        // Nessun JSON obbligatorio qui: per Basic basta 401 + header WWW-Authenticate
    }

    @Override
    public void afterPropertiesSet() {
        setRealmName("demo");
        super.afterPropertiesSet();
    }
}
