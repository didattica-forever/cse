package it.example.demo.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    /**
     * User in-memory per Basic Auth.
     * Credenziali di esempio:
     *   username: user
     *   password: password
     */
    @Bean
    public UserDetailsService userDetailsService(PasswordEncoder passwordEncoder) {
        UserDetails user = User.withUsername("user")
                .password(passwordEncoder.encode("password"))
                .roles("USER")
                .build();

        return new InMemoryUserDetailsManager(user);
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationEntryPoint basicAuthEntryPoint() {
        return new BasicAuthEntryPoint();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http
                // Disabilitazione CSRF per semplicità (solo API REST demo)
                .csrf(csrf -> csrf.disable())

                // Nessun form login, solo HTTP Basic
                .formLogin(form -> form.disable())
                .logout(logout -> logout.disable())

                .httpBasic(Customizer.withDefaults())

                // EntryPoint per 401 Unauthorized con WWW-Authenticate: Basic realm="demo"
                .exceptionHandling(ex -> ex
                        .authenticationEntryPoint(basicAuthEntryPoint())
                )

                .authorizeHttpRequests(auth -> auth
                        // Endpoint di dettaglio: pubblici
                        .requestMatchers(HttpMethod.GET, "/regions/*").permitAll()
                        .requestMatchers(HttpMethod.GET, "/provinces/*").permitAll()
                        .requestMatchers(HttpMethod.GET, "/cities/*").permitAll()

                        // Endpoint di lista: richiedono autenticazione Basic
                        .requestMatchers(HttpMethod.GET, "/regions").authenticated()
                        .requestMatchers(HttpMethod.GET, "/provinces").authenticated()
                        .requestMatchers(HttpMethod.GET, "/cities").authenticated()

                        // Tutto il resto: consentito per ora
                        .anyRequest().permitAll()
                );

        return http.build();
    }
}
