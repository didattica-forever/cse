package it.example.demo.util;

import it.example.demo.dto.PagedResponse;
import org.springframework.hateoas.Link;
import org.springframework.data.domain.Page;

public final class PaginationHelper {

    private PaginationHelper() {
    }

    public static <T> PagedResponse<T> buildPagedResponse(Page<T> pageData,
                                                          Link selfLink,
                                                          Link nextLink,
                                                          Link prevLink) {
        PagedResponse<T> response = new PagedResponse<>(
                pageData.getContent(),
                pageData.getNumber(),
                pageData.getSize(),
                pageData.getTotalElements(),
                pageData.getTotalPages()
        );

        response.add(selfLink);
        if (nextLink != null) {
            response.add(nextLink);
        }
        if (prevLink != null) {
            response.add(prevLink);
        }

        return response;
    }
}
