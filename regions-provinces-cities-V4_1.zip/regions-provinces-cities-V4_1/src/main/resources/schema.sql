DROP TABLE IF EXISTS comuni;
DROP TABLE IF EXISTS province;
DROP TABLE IF EXISTS regioni;

CREATE TABLE regioni (
    id INT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    url VARCHAR(255),
    latitudine DOUBLE,
    longitudine DOUBLE
);

CREATE TABLE province (
    id INT PRIMARY KEY,
    id_regione INT NOT NULL,
    codice_citta_metropolitana VARCHAR(10),
    nome VARCHAR(100) NOT NULL,
    sigla_automobilistica VARCHAR(5),
    latitudine DOUBLE,
    longitudine DOUBLE,
    CONSTRAINT fk_province_regioni
        FOREIGN KEY (id_regione) REFERENCES regioni(id)
);

CREATE TABLE comuni (
    id INT PRIMARY KEY,
    id_regione INT NOT NULL,
    id_provincia INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    capoluogo_provincia TINYINT NOT NULL,
    codice_catastale VARCHAR(10),
    latitudine DOUBLE,
    longitudine DOUBLE,
    CONSTRAINT fk_comuni_regioni
        FOREIGN KEY (id_regione) REFERENCES regioni(id),
    CONSTRAINT fk_comuni_province
        FOREIGN KEY (id_provincia) REFERENCES province(id)
);
