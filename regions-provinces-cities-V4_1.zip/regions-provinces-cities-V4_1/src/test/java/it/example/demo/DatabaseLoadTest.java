package it.example.demo;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
class DatabaseLoadTest {

	private static final Logger logger = LoggerFactory.getLogger(DatabaseLoadTest.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Test
    void shouldLoadExpectedRowCounts() {
        Integer regioni = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM regioni", Integer.class);
        Integer province = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM province", Integer.class);
        Integer comuni  = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM comuni",  Integer.class);

        logger.info("Regioni: {}", regioni);
        logger.info("Province: {}", province);
        logger.info("Comuni : {}", comuni);

        assertEquals(20,  regioni);
        assertEquals(110, province);
        assertEquals(7999, comuni);
    }
}
